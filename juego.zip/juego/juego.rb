user_option     = ARGV[0].downcase
computer_option = rand(3)
options         = ["rock", "paper", "scissors"]

if user_option != "rock" and user_option != "paper" and user_option != "scissors"
    puts "Invalid argument, it must be  rock, paper or scissors"
    exit
end

puts "computer plays #{options[computer_option]}"

#estructuras de control que permiten ejecutar sentencias de código dependiendi de la evaluación lógica anterior
#or= sigue evaluando hasta que alguna condición sea verdadera
if ((computer_option == 0 and user_option == "paper") or (computer_option == 1 and user_option == "scissors") or (computer_option == 2 and user_option == "rock"))
    puts "You win"
elsif ((computer_option == 0 and user_option == "scissors") or (computer_option == 1 and user_option == "rock") or (computer_option == 2 and user_option == "paper"))
    puts "You lost"
else
    puts "Tie"
end

